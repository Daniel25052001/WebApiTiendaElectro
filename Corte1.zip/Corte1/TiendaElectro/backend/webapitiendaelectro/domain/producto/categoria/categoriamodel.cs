


namespace domain.producto.categoria;

public class CategoriaModel
{
    public CategoriaModel()
    {

    }


    public int IdCategoria { get; set; }
    public string Nombre { get; set; }
    public string Descripcion { get; set; }
}