

public class MarcaModel
{
    public MarcaModel() { }

    public int IdMarca { get; set; }
    public string Nombre { get; set; }
}
