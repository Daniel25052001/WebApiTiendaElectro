
public class ModeloModel
{
    public ModeloModel() { }

    public int IdModelo { get; set; }
    public string Nombre { get; set; }
}
