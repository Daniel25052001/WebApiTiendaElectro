


namespace domain.geografia.departamento;


public class DepartamentoModel
{
    public DepartamentoModel()
    {

    }


    public int IdDepartamento { get; set; }
    public int IdPais { get; set; }
    public string Nombre { get; set; }
    
}