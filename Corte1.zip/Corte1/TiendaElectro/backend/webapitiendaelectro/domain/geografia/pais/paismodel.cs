




public class PaisModel
{
    public PaisModel()
    {

    }


    public int IdPais { get; set; }
    public string Nombre { get; set; }
    
}