






namespace domain.geografia.ciudad
{
    public class CiudadModel
    {
        public CiudadModel() { }

        public int IdCiudad { get; set; }
        public int IdDepartamento { get; set; }
        public string Nombre { get; set; }
    }
}
