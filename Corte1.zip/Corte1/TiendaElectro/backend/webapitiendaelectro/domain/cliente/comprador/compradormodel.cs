

public class CompradorModel
{
    public CompradorModel()
    {
    }

    public int IdComprador { get; set; }
    public string Nombre { get; set; }
}