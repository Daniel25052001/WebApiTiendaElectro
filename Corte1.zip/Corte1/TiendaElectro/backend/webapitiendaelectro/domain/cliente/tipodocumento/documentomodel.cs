
public class DocumentoModel
{
    public DocumentoModel()
    {
    }

    public int IdDocumento { get; set; }
    public string Nombre { get; set; }
}
