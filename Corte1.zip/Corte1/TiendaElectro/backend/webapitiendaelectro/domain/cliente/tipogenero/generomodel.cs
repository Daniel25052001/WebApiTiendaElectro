public class GeneroModel
{
    public GeneroModel()
    {
    }

    public int IdGenero { get; set; }
    public string Nombre { get; set; }
}
