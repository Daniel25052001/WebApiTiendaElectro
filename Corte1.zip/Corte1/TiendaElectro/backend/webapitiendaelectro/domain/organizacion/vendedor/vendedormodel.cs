
public class VendedorModel
{
    public VendedorModel() { }

    public int IdVendedor { get; set; }
    public string Nombre { get; set; }
}
