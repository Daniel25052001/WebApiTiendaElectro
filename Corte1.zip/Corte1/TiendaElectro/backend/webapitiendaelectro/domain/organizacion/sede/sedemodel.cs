
public class SedeModel
{
    public SedeModel()
    {
    }

    public int IdSede { get; set; }
    public string Nombre { get; set; }
    public string Direccion { get; set; }
}
