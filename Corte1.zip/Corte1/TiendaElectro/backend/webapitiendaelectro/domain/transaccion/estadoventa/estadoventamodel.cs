

namespace Dominio.Transaccion.EstadoVenta
{
    public class EstadoVentaModel
    {
        public int IdEstadoVenta { get; set; }
        public string Nombre { get; set; }
    }
}
