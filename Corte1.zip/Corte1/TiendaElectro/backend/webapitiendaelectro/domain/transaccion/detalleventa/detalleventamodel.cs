
namespace dominio.transaccion.detalleventa
{
    public class DetalleVentaModel
    {
        public DetalleVentaModel() { }

        public int IdDetalleVenta { get; set; }
        public string Nombre { get; set; }
    }
}
