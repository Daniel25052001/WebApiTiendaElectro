

class ApiTienda
{
    public ApiTienda() { }

    public TiendaModel IngresarTienda(TiendaModel tiendaModel)
    {
        return tiendaModel;
    }

    public TiendaModel ModificarTienda(int idtienda, TiendaModel tiendaModel)
    {
        return tiendaModel;
    }

    public int EliminarTienda(int idtienda)
    {
        return idtienda;
    }

    public string ConsultarTienda()
    {
        return "";
    }
}
