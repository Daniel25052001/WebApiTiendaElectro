

class ApiSede
{
    public ApiSede() { }

    public SedeModel IngresarSede(SedeModel sedeModel)
    {
        return sedeModel;
    }

    public SedeModel ModificarSede(int idSede, SedeModel sedeModel)
    {
        return sedeModel;
    }

    public int EliminarSede(int idSede)
    {
        return idSede;
    }

    public string ConsultarSede()
    {
        return "";
    }
}
