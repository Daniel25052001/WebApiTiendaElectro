

class ApiVendedor
{
    public ApiVendedor() { }

    public VendedorModel IngresarVendedor(VendedorModel vendedorModel)
    {
        return vendedorModel;
    }

    public VendedorModel ModificarVendedor(int idvendedor, VendedorModel vendedorModel)
    {
        return vendedorModel;
    }

    public int EliminarVendedor(int idvendedor)
    {
        return idvendedor;
    }

    public string ConsultarVendedor()
    {
        return "";
    }
}
