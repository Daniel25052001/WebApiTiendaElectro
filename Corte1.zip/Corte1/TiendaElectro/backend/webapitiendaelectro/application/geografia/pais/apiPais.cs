
class ApiPais
{
    public ApiPais() { }
    public PaisModel IngresarPais(PaisModel paisModel)
    {
        return paisModel;
    }

    public PaisModel ModificarPais(int idpais, PaisModel paisModel)
    {
       
        return paisModel;
    }


    public int EliminarPais(int idpais)
    {
        return idpais;
    }

        public string ConsultarPais()
    {
        return "";
    }




}