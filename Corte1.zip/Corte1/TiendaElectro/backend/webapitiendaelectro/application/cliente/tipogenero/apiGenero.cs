

class ApiGenero
{
    public ApiGenero() { }

    public GeneroModel IngresarGenero(GeneroModel generoModel)
    {
        return generoModel;
    }

    public GeneroModel ModificarGenero(int idGenero, GeneroModel generoModel)
    {
        return generoModel;
    }

    public int EliminarGenero(int idGenero)
    {
        return idGenero;
    }

    public string ConsultarGenero()
    {
        return "";
    }
}
