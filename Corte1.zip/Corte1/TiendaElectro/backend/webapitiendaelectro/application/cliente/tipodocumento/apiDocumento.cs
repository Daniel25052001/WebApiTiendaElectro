

class ApiDocumento
{
    public ApiDocumento() { }

    public DocumentoModel IngresarDocumento(DocumentoModel documentoModel)
    {
       
        return documentoModel;
    }

    public DocumentoModel ModificarDocumento(int idDocumento, DocumentoModel documentoModel)
    {
       
        return documentoModel;
    }

    public int EliminarDocumento(int idDocumento)
    {
       
        return idDocumento;
    }

    public string ConsultarDocumento()
    {
        
        return "";
    }
}
