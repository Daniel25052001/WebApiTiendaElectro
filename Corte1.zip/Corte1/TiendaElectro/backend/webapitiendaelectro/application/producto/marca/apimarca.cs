
class ApiMarca
{
    public ApiMarca() { }

    public MarcaModel IngresarMarca(MarcaModel marcaModel)
    {
        return marcaModel;
    }

    public MarcaModel ModificarMarca(int idMarca, MarcaModel marcaModel)
    {
        return marcaModel;
    }

    public int EliminarMarca(int idMarca)
    {
        return idMarca;
    }

    public string ConsultarMarca()
    {
        return "";
    }
}
