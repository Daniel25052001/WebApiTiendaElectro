
class ApiModelo
{
    public ApiModelo() { }

    public ModeloModel IngresarModelo(ModeloModel modeloModel)
    {
        return modeloModel;
    }

    public ModeloModel ModificarModelo(int idModelo, ModeloModel modeloModel)
    {
        return modeloModel;
    }

    public int EliminarModelo(int idModelo)
    {
        return idModelo;
    }

    public string ConsultarModelo()
    {
        return "";
    }
}
